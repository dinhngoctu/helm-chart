This directory contains Jansi native libraries, extracted from Jansi jar.

You can add your own extensions for platforms not natively supported by
Jansi: the libraries follow HawtJNI directory and filename conventions.
See http://fusesource.github.io/hawtjni/documentation/api/org/fusesource/hawtjni/runtime/Library.html

See https://github.com/fusesource/jansi-native for native lib source.
